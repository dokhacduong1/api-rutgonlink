class Key {
    constructor(key) {
        this.key = key;
    }
}
